![](https://github.com/jaleelx98/BadRobo/blob/main/BadRobo_banner.png)



----
## UPDATED 
### GIVE US A STAR AND SUPPORT US ❤️️
### FREE BOT

![](https://github.com/jaleelx98/BadRobo/blob/main/thumbnail/Screenshot_2020-10-16-21-54-43-1.png)

## Table of Contents


- [Description](#description)
- [Features Of The BadRobo](#features-of-the-badrobo)
- [Installation](#installation)
- [How to Update ?](#UPDATING)
- [Tutorial Video](#video-tutorial)
- [License](#license)
- [Contact Us](#contact-us)
- [Donate](#Donate)
----
# Description
- GIVE US A STAR 🌟
- Best Instagram Bot For Termux With All Features.
- Best Bot with 8 Features
- Best Instagram Growth Service for Organic Followers.
- Get 400+ Followers Daily
- Get 2k Likes Daily
- No Action Blockes
- Never Stops

![](https://github.com/jaleelx98/Bad-Robo/blob/main/thumbnail/20201016_221726.gif)

---
# Features Of The BadRobo

- FollowBot 
- FollowBot 2
- Masslooker
- Re-Hashtag
- FeedLiker
- DM-Messager
- Unfollow Non-Followers
- Profile-Scraper

![](https://github.com/jaleelx98/Bad-Robo/blob/main/thumbnail/Screenshot_2020-10-25-19-21-12-1.png)

---
# Installation

Step 1 (Clone or Download)
```
git clone https://github.com/jaleelx98/Bad-Robo.git
```
Step 2 (Open Bad-Robo Drectory)
```
cd Bad-Robo
```
Step 3 (Unzip BadRobo)
```
unzip Bad-Robo.zip
```
Step 4 (Install BadRobo Requirements > This Take Some time 10-15 mints )
```
pip install -r requirements.txt
```
Step 5 (Run BadRobo)
```
python badrobo.py
```

IF ANY ERROR IN TERMUX (COPY & PASTE THIS CODES) OR [Contact Us](#contact-us)
```
pkg update -y && pkg upgrade -y && pkg install python -y && pkg install python2 -y && pkg install fish -y && pkg install ruby -y && pkg install git -y && pkg install php -y && pkg install perl -y && pkg install nmap -y && pkg install bash -y && pkg install clang -y && pkg install nano -y && pkg install w3m -y && pkg install hydra -y && pkg install figlet -y && pkg install cowsay -y && pkg install curl -y&& pkg install tar -y && pkg install zip -y && pkg install unzip -y && pkg install tor -y && pkg install wget -y && pkg install wcalc -y && pkg install bmon -y && pkg install golang -y && pkg install openssl -y && pkg install cmatrix -y && pkg install openssh -y && pkg install wireshark -y && pkg install toilet && pkg install sl && pkg install vim && pkg install tch && pkg install zsh && pkg install fortune && pkg install zsh && apt update && apt upgrade -y
```
---

# UPDATING

Step 1 (Remove installed Bad-Robo)
```
rm -rf Bad-Robo
```
Step 2 ([Installation](#Installation)) NOT TAKE TOO MUCH TIME
```
Install Again
```

---
## Video Tutorial 
### https://youtu.be/EoLr5Brx1Rk
---
## License
##### Copyright (c) [2020] [jaleel_x98]
##### Licensed under the Apache License, Version 2.0
---
## Contact Us
- [Instagram](https://instagram.com/jaleel_x98) 
- [Whatsapp](https://wa.me/+917034569325)
---

# Donate
#### Support And Join Our Family....!
#### Consider donating ❤️️
<a href="https://wa.me/+917034563925"><img src="https://github.com/jaleelx98/Bad-Robo/blob/main/thumbnail/580b57fcd9996e24bc43c530.png" align="left" height="55" ></a>
---

